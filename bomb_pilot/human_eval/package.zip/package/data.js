window.STUDY = {
 "stories": {
  "cafe_bomb": {
   "intro": "你将逐个镜头观看一部短片，故事发生在一家小咖啡馆里。",
   "question": "根据目前看到的内容，你觉得这个场景最后会怎样？",
   "options": {
    "calm": "两人聊完天，平静地离开，什么坏事都没发生",
    "escape": "发生了危险的事，但他们安然无恙",
    "harm": "发生了危险的事，并且有人受伤"
   },
   "versions": {
    "surprise": [
     "s1_establish",
     "s2_filler",
     "s3_woman",
     "s4_man",
     "s5_clock",
     "s6_explosion"
    ],
    "suspense": [
     "s1_establish",
     "s2_reveal",
     "s3_woman",
     "s4_man",
     "s5_clock",
     "s6_explosion"
    ]
   },
   "reveal_index": 1,
   "final_index": 5,
   "harm_option": "harm"
  },
  "poisoned_wine": {
   "intro": "你将逐个镜头观看一部短片，故事发生在一座古老豪宅里的晚宴上。",
   "question": "根据目前看到的内容，你觉得这场晚宴最后会怎样？",
   "options": {
    "calm": "晚宴愉快结束，什么坏事都没发生",
    "escape": "有人策划了阴谋，但年轻人最终安然无恙",
    "harm": "年轻人受到了伤害"
   },
   "versions": {
    "surprise": [
     "s1_establish",
     "s2_filler",
     "s3_serve",
     "s4_toast",
     "s5_drink",
     "s6_collapse"
    ],
    "suspense": [
     "s1_establish",
     "s2_reveal",
     "s3_serve",
     "s4_toast",
     "s5_drink",
     "s6_collapse"
    ]
   },
   "reveal_index": 1,
   "final_index": 5,
   "harm_option": "harm"
  },
  "thin_ice": {
   "intro": "你将逐个镜头观看一部短片，故事发生在冬天结冰的湖面上。",
   "question": "根据目前看到的内容，你觉得这个场景最后会怎样？",
   "options": {
    "calm": "他开心地滑完冰，安全回家，什么坏事都没发生",
    "escape": "发生了危险的事，但他安然无恙",
    "harm": "发生了危险的事，并且他受伤了"
   },
   "versions": {
    "surprise": [
     "s1_establish",
     "s2_filler",
     "s3_skate",
     "s4_center",
     "s5_blades",
     "s6_break"
    ],
    "suspense": [
     "s1_establish",
     "s2_reveal",
     "s3_skate",
     "s4_center",
     "s5_blades",
     "s6_break"
    ]
   },
   "reveal_index": 1,
   "final_index": 5,
   "harm_option": "harm"
  }
 },
 "assignments": [
  {
   "rater": "R01",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R02",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R03",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R04",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R05",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R06",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R07",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R08",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R09",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R10",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R11",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R12",
   "videos": [
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R13",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R14",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R15",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R16",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R17",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R18",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R19",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R20",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R21",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R22",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R23",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R24",
   "videos": [
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R25",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R26",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R27",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R28",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R29",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R30",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R31",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R32",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 0
    }
   ]
  },
  {
   "rater": "R33",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 1
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R34",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 1
    }
   ]
  },
  {
   "rater": "R35",
   "videos": [
    {
     "story": "thin_ice",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "suspense",
     "seed": 2
    },
    {
     "story": "cafe_bomb",
     "version": "surprise",
     "seed": 2
    }
   ]
  },
  {
   "rater": "R36",
   "videos": [
    {
     "story": "thin_ice",
     "version": "suspense",
     "seed": 0
    },
    {
     "story": "poisoned_wine",
     "version": "surprise",
     "seed": 0
    },
    {
     "story": "cafe_bomb",
     "version": "suspense",
     "seed": 2
    }
   ]
  }
 ]
};
